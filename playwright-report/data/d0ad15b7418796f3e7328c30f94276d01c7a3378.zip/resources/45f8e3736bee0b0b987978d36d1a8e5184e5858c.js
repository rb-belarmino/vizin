(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_1_alqx1._.js","static/chunks/src_0e7mf-u._.js"],
    source: "dynamic"
});
